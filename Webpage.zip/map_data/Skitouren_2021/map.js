var map_Skitouren = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#7e7e7e",
        "marker-size": "medium",
        "marker-symbol": "lodging"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          9.563126564025879,
          46.650909127403025
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#c6c6c6",
        "marker-size": "medium",
        "marker-symbol": "skiing"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          9.48493480682373,
          46.65261771544999
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#c6c6c6",
        "marker-size": "medium",
        "marker-symbol": "skiing"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          9.50068473815918,
          46.62297489906401
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#c6c6c6",
        "marker-size": "medium",
        "marker-symbol": "skiing"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          9.500083923339844,
          46.64301357135849
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#c6c6c6",
        "marker-size": "medium",
        "marker-symbol": "skiing"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          9.766416549682617,
          46.67252762304416
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#c6c6c6",
        "marker-size": "medium",
        "marker-symbol": "skiing"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          9.72501,
          46.51019
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#c6c6c6",
        "marker-size": "medium",
        "marker-symbol": "skiing"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          9.595355987548828,
          46.46523620335958
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#3e3d3d",
        "marker-size": "medium",
        "marker-symbol": "pitch"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          9.5416259765625,
          46.78713177547821
        ]
      }
    }
  ]
}
